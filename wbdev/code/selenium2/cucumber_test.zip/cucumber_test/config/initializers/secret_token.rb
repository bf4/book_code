# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CucumberTest::Application.config.secret_token = '93a464648183b0445b9a19db91b8728374087fef30c27880b1182974bb50bc2f388b595de4f0ff54a832d2a7808a3c7fab5d7f7570522edac24ab542412f838a'
